import React from 'react';

function search(props) {
    return (
        <svg width="17" height="18" viewBox="0 0 17 18" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="6.68557" cy="7.00347" r="5.9233" stroke="#D2B5B1" strokeWidth="1.31629"/>
<path d="M11.1964 11.5314L16.0802 16.578" stroke="#D2B5B1" strokeWidth="1.81629"/>
</svg>

    );
}

export default search;