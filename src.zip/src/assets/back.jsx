import React from 'react'

function back(props) {
  return (
    <svg width="35" height="35" viewBox="0 0 46 45" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect x="0.348755" y="22.4585" width="30.7625" height="7.79788" rx="3.1021" transform="rotate(-44.9689 0.348755 22.4585)" fill="#8D8D8D"/>
<rect x="3.65128" y="19" width="42" height="8" rx="3.1021" fill="#8D8D8D"/>
<rect x="5.84964" y="17.3009" width="30.7625" height="7.80094" rx="3.1021" transform="rotate(44.0001 5.84964 17.3009)" fill="#8D8D8D"/>
</svg>
  )
}

export default back;